#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
using namespace std;





	class library { 
		public:
			string id;
			string name;
			string author;
			string delaycost;
			string rentedby;
			string deliverdate;
			string inline_num;
			string in_line[50];
	};
	library Book[50];
	string books_num;
	int books_num2;
	int inline_num2;
	string temp;
	int temp_;




	class Usersclass {
		public: 
			string id;
			string password;
			string fname;
			string lname;
			string phonenum;
			string borrownum;
			string borrowed[8];
	};
	Usersclass User[50];	
	int users_num;
	string z1;
	int z2;
	string x;





	class Adminsclass {
		public: 
			string id;
			string password;
			string fname;
			string lname;
			
	};
	Adminsclass Admin[10];
	int admins_num;
	
	
	






////////////////
string random_id() {
  
  string id = "";
  char t;
  char chars[] = {'0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9',
  '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L',
  'M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k',
  'l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
  
  

    
    for(int i = 0;i<10;i++){
      
      t= chars[rand()%82];
      id += t;
    }


  return id;
}


bool id_check(string new_id) {
	
	for (int i=0; i<books_num2; i++) {
		
		if (new_id==Book[i].id) {
			return false;
		}
		
		if (i==books_num2-1) {
			return true;
		}
		
	}
	
}






///////////////
void usersavetofile() {
	
		ofstream edit("Users.txt");
			for (int i=0; i<users_num; i++) {
					
				edit << User[i].id << endl;
				edit << User[i].password << endl;
				edit << User[i].fname << endl;
				edit << User[i].lname << endl;
				edit << User[i].phonenum << endl;
				edit << User[i].borrownum << endl;
					
				int temp2= stoi(User[i].borrownum);
					
				for (int j=0; j<temp2; j++) {
					edit << User[i].borrowed[j] << endl;
				}
				
				if (i!=users_num-1) { edit << "//////////////////////////////////////////////////////////////////////" << endl; }
				else if (i==users_num-1) { edit << "////////////////////////////////////////////////////////////////////////"; }
					
				}
		edit.close();
}





/////////////////
void booksavetofile() {
	
		ofstream book_export("Books.txt");
				for (int i=0; i<books_num2; i++) {
					
					book_export << Book[i].id << endl;
					book_export << Book[i].name << endl;
					book_export << Book[i].author << endl;
					book_export << Book[i].delaycost << endl;
					book_export << Book[i].rentedby << endl;
					book_export << Book[i].deliverdate << endl;
					book_export << Book[i].inline_num << endl;
					
					inline_num2= stoi(Book[i].inline_num);
					
					for (int j=0; j<inline_num2; j++) {
						
						book_export << Book[i].in_line[j] << endl;
						
					}
					
					if (i!=books_num2-1) { book_export << "/////////////////////////////////////////////////////////////" << endl;}
					else { book_export << "///////////////////////////////////////////////////////";}
					
					
				}
				book_export.close();

}






//////////////////
void booknumchange(string a) {
	
	if (a=="decrease") {
		books_num2--;
	}
	
	if (a=="increase") {
		books_num2++;
	}
	
	books_num= to_string(books_num2);
	
	ofstream change("Books_num.txt");
	change << books_num;
	change.close();
}




////////////
int localdate(string datetype) {
	
	time_t now;
	struct tm localnow;
	now= time(NULL);
	localnow= *localtime(&now);
	
	if (datetype== "Day") {
		return localnow.tm_mday;
	}

	if (datetype== "Month") {
		return localnow.tm_mon;
	}	
	
	if (datetype=="Year") {
		return localnow.tm_year;
	}

	return 0;	
}





void book_sort(int num) {
	
	library temp;
	
	for (int i=0; i<num; i++) {
		
		for (int j=0; j<num-1-i; j++) {
			
			if (Book[j].id[0] > Book[j+1].id[0] ) {
				
				temp= Book[j];
				Book[j]= Book[j+1];
				Book[j+1]= temp;
			}	
		}	
	}
}





void book_import_func() {
	
	ifstream booknum_import("Books_num.txt");
	getline(booknum_import, books_num);
	books_num2= stoi(books_num);
	booknum_import.close();
	
	
	ifstream book_import("Books.txt");
	for (int i=0; i<books_num2; i++) {
		
		getline (book_import, Book[i].id);
		getline (book_import, Book[i].name);
		getline (book_import, Book[i].author);
		getline (book_import, Book[i].delaycost);		
		getline (book_import, Book[i].rentedby);
		getline (book_import, Book[i].deliverdate);					
		getline (book_import, Book[i].inline_num);
		inline_num2= stoi (Book[i].inline_num);
		
		for (int j=0; j<inline_num2; j++) {
			
			getline (book_import, Book[i].in_line[j]);
		}
	
		getline (book_import, temp);
	
	}
	book_import.close();
	
	
	
	
}







int main() {

//////////////////////////////////////////import kardane ketab ha//////////////////////////////////////////////////////////
	
	
	book_import_func();
	
	
/////////////////////////////////////////////////////// import kardane user ha //////////////////////////////////////////////////////




	ifstream usersize("Users_num.txt");
	getline(usersize,temp);		
	users_num= stoi(temp);
	usersize.close();
	


	ifstream userimport("Users.txt");
	for (int i=0; i<users_num; i++) {
		
		getline(userimport, User[i].id);
		getline(userimport, User[i].password);
		getline(userimport, User[i].fname);
		getline(userimport, User[i].lname);
		getline(userimport, User[i].phonenum);
		getline(userimport, User[i].borrownum);
		
		z2=stoi(User[i].borrownum);
		
		for (int j=0; j<z2; j++) {
			getline(userimport,User[i].borrowed[j]); 
		}
		
		getline(userimport, x);
		
	}	
	userimport.close();
	
	
////////////////////////////////////////import kardane admin ha///////////////////////////////////////
	
	
	ifstream adminsize("Admins_num.txt");
	getline(adminsize, temp);
	admins_num = stoi(temp);
	adminsize.close();
	
	


	ifstream adminimport("Admins.txt");
	for (int i=0; i<admins_num; i++) {
		
		getline (adminimport, Admin[i].id);
 		getline (adminimport, Admin[i].fname);
		getline (adminimport, Admin[i].lname);
		getline (adminimport, Admin[i].password);
		getline (adminimport, x);
		
	}
	adminimport.close();
	
	
	
//////////////////////////// login page ///////////////////////////////////////////////////////
	
	
	login:
	cout << " WELCOME TO OUR LIBRARY!! :)" << endl;
	cout << " PLEASE CHOOSE YOUR POSITION: " << endl << endl;
	cout << " 1. LIBRARIAN" << "	   	   " << " 2. USER" << "		" << " 3. I WANT TO SIGN UP." << endl;
	cout << " ??: ";


	int inp;
	string position;
	
	do {
		cin >> inp;
		if (inp!=1 && inp!=2 && inp!=3) {
		cout << endl << " WRONG INPUT!!" << endl;
		cout << " ENTER ANOTHER: ";
		}
	}
	while (inp!=1 && inp!=2 && inp!=3 );

	

	
	cout << "--------------------------------------------------------------------------" << endl;
	
	
	string admin_id;
	string admin_pass;
	string user_id;
	string user_pass;
	
	

	int iterator;
	
	
	switch (inp) {
/////////////////////////////////////////////admin login///////////////////////////////////////////////////////		
		case 1:
		
			here:
			cout << endl << " ENTER YOUR ID: ";
			cin >> admin_id;
			
			for (int i=0; i<admins_num; i++) {
				
				if (admin_id==Admin[i].id) {
					here2:
					cout << endl << " ENTER YOUR PASSWORD: ";
					cin >> admin_pass;
					
					if (admin_pass==Admin[i].password) {
						position= "admin";
						iterator=i;
						usleep(300000);
						system("cls");
						cout << endl << " Welcome to your library " << Admin[i].fname << " " << Admin[i].lname << "!!" << endl;
						cout << "------------------------------------------------------------------" << endl;
						iterator=i;
						usleep(3000000);
						break;
					}
					else {
						system("cls");
						cout << endl << " WRONG PASSWORD!!" << endl;
						goto here2;
					}
				}
				
				if (i==admins_num-1 && admin_id!=Admin[i].id) {
					system("cls");
					cout << endl << " WRONG NAME!!" << endl;
					goto here;
				}
			
			}
			
			break;
		
		
		case 2:
//////////////////////////////////////////////user login/////////////////////////////////////////////////////////////
			here3:
			cout << endl << " ENTER YOUR ID: ";
			cin >> user_id;
			
			for (int i=0; i<users_num; i++) {
				
				if (user_id==User[i].id) {
					here4:
					cout << endl << " ENTER YOUR PASSWORD: ";
					cin >> user_pass;
					if (user_pass==User[i].password) {
						position= "user";
						iterator=i;
						usleep(300000);
						system("cls");
						cout << endl << " Welcome back " << User[i].fname << " " << User[i].lname << "!!" << endl;
						cout << "-----------------------------------------------------------------------" << endl;
						usleep(3000000);
						break;
					}
					else {
						system("cls");
						cout << endl << " WRONG PASSWORD!!" << endl;
						goto here4;
					}
				} 
				
				if (i==users_num-1 && user_id!=User[i].id) {
					system("cls");
					cout << endl << " WRONG USERNAME!!" << endl;
					goto here3;
				}
				
				
			}	
			
			break;
			
			
		case 3:			
////////////////////////////////////////////////user sign up///////////////////////////////////////////////////////
				signup:
				string newuser_id;
				string newuser_password;
				string confpass;
				string newuser_fname;
				string newuser_lname;
				string newuser_phonenum;
				string temp;
				
				usleep(250000);
				system("cls");
				cout << endl << " PLEASE ENTER YOUR FIRST NAME: ";
				cin >> newuser_fname;
				usleep(250000);
				system("cls");
				cout << endl << " PLEASE ENTER YOUR LAST NAME: ";
				cin >> newuser_lname;
				usleep(250000);
				system("cls");
				cout << endl << " PLEASE ENTER YOUR PHONE NUMBER: ";
				cin >> newuser_phonenum;
				usleep(250000);
				system("cls");
				wrongconfirm:
				usleep(250000);
				system("cls");
				cout << endl << " PLEASE ENTER YOUR PASSWORD: ";
				cin >> newuser_password;
				usleep(250000);
				system("cls");
				cout << endl << " PLEASE CONFIRM YOUR PASSWORD: ";
				cin >> confpass;
				
				if (confpass!=newuser_password) {
				
					system("cls");
					cout << endl << " WRONG CONFIRMATION!!" << endl;
					usleep(800000);
					goto wrongconfirm;
				}
		
		
				srand(time(0));
				bool t;
				unsigned long long int a;
				string b;

				do {
	
					a=2000000000+rand()%999999999;
					b = to_string(a);
		
					for (int i=0; i<users_num; i++) {
			
						if (b==User[i].id) {
							t=false;
							break;
						}
			
						if (i==users_num-1 && b!=User[i].id) {
							t=true;
						}
			
					}
		
		
					}
					while (t==false);
					
				newuser_id=b;
				
				User[users_num].id = newuser_id;
				User[users_num].password = newuser_password;
				User[users_num].fname = newuser_fname;
				User[users_num].lname = newuser_lname;
				User[users_num].phonenum = newuser_phonenum;
				User[users_num].borrownum= '0';
		
				iterator=users_num;
				users_num++;		
				temp= to_string(users_num);
				ofstream numincrease("Users_num.txt");
				numincrease << temp;
				numincrease.close();
		
				usersavetofile();
		
				system("cls");
				
				cout << endl << " YOU ARE SIGNED UP SUCCESSFULLY!!" << endl;
				
				usleep(2500000);
				system("cls");
				
				cout << endl;
				cout << " THANK YOU FOR CHOOSING OUR LIBRARY. YOU CAN NOW ENJOY OUR WIDE RANGE OF BOOKS." << endl;
				cout << " HERE IS YOUR LIBRARY ID: " << newuser_id << endl;
				cout << "-----------------------------------------------------------" << endl;
				usleep(10000000);
				position="user";
						
				break;
			
		

	}
	
	
	
///////////////////////////////////////////////////////////////////////user interface//////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	int inp2;
	
	mainmenu:
	system("cls");
	
	if (position== "user") {
		
		cout << endl;
		cout << " WHAT WOULD YOU LIKE TO DO?" << endl << endl;
		cout << " 1. EDIT MY ACCOUNT INFORMATION." << endl;
		cout << " 2. BORROW A BOOK " << endl;
		cout << " 3. RETURN A BOOK." << endl;
		cout << " 4. INCREASE BORROW TIME." << endl;
		cout << " 5. PAY THE DELIVER DELAY PENALTY." << endl;
		cout << " 6. SEE BORROWED BOOKS INFO." << endl;
		cout << " ??: ";
		
		
		do {
		cin >> inp;
		if (inp!=1 && inp!=2 && inp!=3 && inp!=4 && inp!=5 && inp!=6) { cout << endl << " WRONG INPUT!!" << endl;
		cout << " ENTER ANOTHER: ";
			}
		}
		while (inp!=1 && inp!=2 && inp!=3 && inp!=4 && inp!=5 && inp!=6);
		
	
	
	
		string passconf; // case 1
		string newpass; // case 1
		string phonenumconf; // case 1
		string newphonenum; // case 1
		string bookname; // case 4,5
		int book_i; // case 4
		string day; // case 4
		string month; // case 4
		string year;// case 4
		int day_; // case 4
		int month_; // case 4
		int year_; // case 4
		int sum; // case 4
		int latencyprice; // case 5
		string user_inp; // case 2
		int user_inp2; // case 2
		int borrow_num; //case 2,3
		//user operation variables//
		
				
		switch (inp) {
/////////////////////////////////////////////////////////////edit profile//////////////////////////////////////////////////////////////		
			case 1:
				
				edit_profile:
					
				system("cls");
				
				cout << endl << " WHAT WOULD YOU LIKE TO EDIT?" << endl;
				cout << " 1. MY PASSWORD." << "		" << "2. MY PHONE NUMBER." << endl;
				cout << " ??: ";
				
				do {
					cin >> inp2;
					if (inp2!=1 && inp2!=2) { cout << endl << " WRONG INPUT!!" << endl;
					cout << " ENTER ANOTHER: ";
						}
				}
				while (inp2!=1 && inp2!=2);
				

				
				switch(inp2) {
				
				
					case 1:
					
						wrongpassinp:
						cout << endl << " ENTER YOUR CURRENT PASSWORD: ";
						cin >> passconf;
						if (passconf==User[iterator].password) {
							cout << endl << " ENTER YOUR NEW PASSWORD: ";
							cin >> newpass;
							User[iterator].password= newpass;
							usleep(500000);
							system("cls");
							cout << endl << " YOUR PASSWORD HAS BEEN CHANGED SUCCESSFULLY!! :)" << endl;
							usleep(300000);
						}
						else {
							cout << endl << " WRONG PASSWORD!!";
							usleep(300000);
							goto wrongpassinp;
						}

						break;
						
						
					case 2:

						wrongphonenuminp:
						cout << endl << " ENTER YOUR CURRENT PHONE NUMBER: ";
						cin >> phonenumconf;
						
						if (phonenumconf==User[iterator].phonenum) {
							cout << endl << " ENTER YOUR NEW PHONE NUMBER: ";
							cin >> newphonenum;
							User[iterator].phonenum=newphonenum;
							usleep(500000);
							cout << endl << " YOUR PHONE NUMBER HAS BEEN CHANGED SUCCESSFULLY!! :)";
							usleep(3000000);
						} else {
							cout << endl << " THIS IS NOT YOUR PHONE NUMBER.";
							goto wrongphonenuminp;
						}
						
						break;
					
					
					default:
						
						goto edit_profile;
						break;
						
				}
				
				
				usersavetofile();
				
				
				
				cout << " 1.  EDIT PROFILE AGAIN." << "		" << " 2. GO TO MAIN MENU." << endl;
				cout << "??: ";
				cin >> user_inp2;
				switch (user_inp2) {
					case 1:
						usleep(300000);
						goto edit_profile;
						break;
					case 2:
						usleep(300000);
						goto mainmenu;
						break;
					default:
						usleep(300000); 
						goto mainmenu;
						break;
				}
		
		
				
				break;	
			
			
			
///////////////////////////////////////////////////borrow a book/////////////////////////////////////////////////////////////////////////
			case 2:
				
				search_another:
				
				system("cls");
					
				cout << endl << " PLEASE ENTER THE BOOK'S TITLE': ";
				getline(cin, bookname);
				getline(cin, bookname);
				
				for (int i=0; i<books_num2; i++) {
					
					if (Book[i].name==bookname) {
						book_i=i;
						break;
					} 
					if (i==books_num2-1) {
						cout << endl << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY!" << endl;
						cout << " 1. SEARCH ANOTHER ONE." << endl;
						cout << " 2. GO TO MAIN MENU." << endl;
						cout << " ??: ";
						cin >> temp_;
						switch (temp_) {
							case 1:
								usleep(300000);
								goto search_another;
								break;
							case 2:
								usleep(300000);
								goto mainmenu;
								break;
							default: 
								usleep(300000);
								goto mainmenu;
								break;
						}
					}
					
				}
				
				
				borrow_num= stoi(User[iterator].borrownum);
				inline_num2= stoi(Book[book_i].inline_num); 
				
				if (borrow_num==8) {
					cout << endl << " YOU CANNOT BORROW ANYMORE BOOKS!" << endl;
					cout << " YOU HAVE REACHED THE LIMIT." << endl << endl;
					usleep(3000000);
					
					system("cls");
					cout << "GOING TO MAIN MENU.";
					usleep(500000);
					system("cls");
					cout << "GOING TO MAIN MENU..";
					usleep(500000);
					system("cls");
					cout << "GOING TO MAIN MENU...";
					usleep(500000);
					goto mainmenu;
						
				}
				
				
				if (Book[book_i].rentedby=="0") {
					
					Book[book_i].rentedby= User[iterator].id;
					User[iterator].borrowed[borrow_num]= Book[book_i].id;
					borrow_num++;
					User[iterator].borrownum= to_string(borrow_num);

					
					month_= localdate("Month");
					day_= localdate("Day");
					year_= localdate("Year")+1900;
					
					month_+=2;
					
					if (month_>11) {
						year_++;
						month_=month_-11;
					}
						
					year=to_string(year_);
					
					if (month_<10) { month= "0"+to_string(month_);}
					else { month=to_string(month_); }
					
					if (day_<10) { day= "0"+to_string(day_);}
					else { day=to_string(day_); }
					
					Book[book_i].deliverdate= year+day+month;
					
					system("cls");
					cout << endl << " You have borrowed " << Book[book_i].name << "." << endl;
					cout << " Your return date is: " << year << " " << day << " " << month << endl;
					cout << " Latency cost per day is: " << Book[book_i].delaycost << endl;
					cout << " Hope you enjoy the book! :) " << endl << endl;
					
					usersavetofile();
					booksavetofile();
					
					cout << " 1. BORROW ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
					cout << "??: ";
					cin >> temp_;
					switch (temp_) {
						case 1:
							goto search_another;
							break;
						case 2:
							goto mainmenu;
							break;
						default: 
							goto mainmenu;
							break;
					}
					
				} else {
					
					usleep(300000);
					system("cls");
					
					cout << endl << " THIS BOOK IS ALREADY BORROWED BY ANOTHER MEMBER." << endl;
					cout << " DO YOU WANT TO RESERVE IT?" << endl;
					cout << " 1. YES" << endl << " 2. NO,LET'S BORROW ANOTHER ONE." << endl << " 3. NO,GO TO MAIN MENU." << endl;
					cout << "??: ";
					cin >> temp_;
					switch (temp_) {	
						
						case 1:
							
							Book[book_i].in_line[inline_num2]= User[iterator].id;
							inline_num2++;
							Book[book_i].inline_num= to_string(inline_num2);
							
							system("cls");
							cout << endl << " THE BOOK HAS BEEN RESERVED FOR YOU.";
							cout << endl << " You are the number " << inline_num2 << " in line.";
							cout << endl << " The book's latency cost is: " << Book[book_i].delaycost << endl;
							
							usersavetofile();
							booksavetofile();
							
							cout << endl << " WHAT TO DO NEXT?" << endl;
							cout << endl << " 1. BORROW ANOTHER BOOK.";
							cout << endl << " 2. GO TO MAIN MENU." << endl;
							cout << "??: ";
							cin >> user_inp2;
							switch (user_inp2) {
								case 1:
									usleep(300000);
									goto search_another;
									break;
								case 2:
									usleep(300000);
									goto mainmenu;
									break;
								default:
									usleep(300000);
									goto mainmenu;
									break;
							}
							
							
							break;
						case 2:
							usleep(300000);
							goto search_another;
							break;		
											
						case 3:
							usleep(300000);
							goto mainmenu;
							break;
								
						default: 
							usleep(300000);
							goto mainmenu;
							break;
							
						}
						
						
						
				}
				
				
				
				
				
				break;
				
				
				
				
///////////////////////////////////////////////////returning a book/////////////////////////////////////////////////////////////////////
			case 3:
			
				search_another3:
				
				system("cls");	
				
				cout << endl << " ENTER THE BOOK'S TITLE: ";
				getline(cin,bookname);
				getline(cin,bookname);
				for (int i=0; i<books_num2; i++) {
					
					if (Book[i].name==bookname) {
						if (Book[i].rentedby==User[iterator].id) {
						book_i=i;
						break;
						}
						else {  
								system("cls");
								
								cout << "YOU DIDN'T BORROW THIS BOOK!" << endl;
								cout << endl << " 1. SEARCH FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU" << endl;
								cout << "??: ";
								cin >> temp_;
								switch (temp_) {
									case 1:
										usleep(300000);
										goto search_another3;
										break;
									case 2:	
										usleep(300000);
										goto mainmenu;
										break;
									default:
										usleep(300000);
										goto mainmenu;
										break; 
									}
							}
					}
					if (i==books_num2-1) {
						cout << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY" << endl;
						cout << endl << " 1. SEARCH FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU" << endl;
						cout << "??: ";
						cin >> temp_;
						switch (temp_) {
							case 1:
								goto search_another3;
								break;
							case 2:	
								goto mainmenu;
								break;
							default:
								goto mainmenu;
								break; 
						}
					}
				}
				
				
				temp_= stoi(Book[book_i].deliverdate);
				month_= temp_%100;
				temp_= temp_/100;
				day_= temp_%100;
				temp_= temp_/100;
				year_= temp_;
				temp_= (year_-(localdate("Year")+1900))*365 + (month_-localdate("Month")-1)*30 + (day_-localdate("Day"));
				if (temp_<0) {
					temp_= temp_*(-1);
					latencyprice= stoi(Book[book_i].delaycost);
					cout << endl << " Your latency penalty is: " << temp_*latencyprice << " Tomans;"; 
				}
				
				
				////hazfe ketab az aray e user///
				borrow_num= stoi(User[iterator].borrownum);
				for (int i=0; i<borrow_num; i++) {
					
					if (Book[book_i].id==User[iterator].borrowed[i]) {
						
						for (int j=i; j<borrow_num-1; j++) {
							
							User[iterator].borrowed[j]= User[iterator].borrowed[j+1];
						
						}	
					}
				}
				borrow_num--;
				User[iterator].borrownum= to_string(borrow_num);
				usersavetofile();
				cout << endl << " THANK YOU FOR RETURNING THE BOOK!! :)" << endl;
				
				
				/////gharz dadane ketab be yeki dg////
				if (Book[book_i].inline_num=="0") {
					
					Book[book_i].rentedby= "0";
					Book[book_i].deliverdate= "no date";
					booksavetofile();
					
				} else {
					
					/////////in books file////////////
					Book[book_i].rentedby= Book[book_i].in_line[0];
					inline_num2= stoi(Book[book_i].inline_num);
					for (int j=0; j<inline_num2-1; j++) {
						
						Book[book_i].in_line[j]=Book[book_i].in_line[j+1];	
						
					}
					inline_num2--;
					Book[book_i].inline_num= to_string(inline_num2);
					
					
					
					month_= localdate("Month");
					day_= localdate("Day");
					year_= localdate("Year")+1900;
					month_+=2;
					if (month_>11) {
						year_++;
						month_=month_-11;
					}
					year=to_string(year_);
					if (month_<10) { month= "0"+to_string(month_);}
					else { month=to_string(month_); }
					if (day_<10) { day= "0"+to_string(day_);}
					else { day=to_string(day_); }
					Book[book_i].deliverdate= year+day+month;
					
					
					booksavetofile();
					
					
				////////////////in receiver users file///////////////////
					for (int j=0; j<users_num; j++) {
					
						if (Book[book_i].rentedby==User[j].id) {
							
							iterator=j;
							break;
						}
					
					}
					
					
					
					borrow_num= stoi(User[iterator].borrownum);
					User[iterator].borrowed[borrow_num]= Book[book_i].id;
					borrow_num++;
					User[iterator].borrownum= to_string(borrow_num);
					usersavetofile();
					
				}
				
				
				cout << endl << " WHAT TO DO NEXT?: " << endl;
				cout << endl << " 1. RETURN ANOTHER BOOK.";
				cout << endl << " 2. GO TO MAIN MENU.";
				cout << endl << "??: ";
				cin >> user_inp2;
				
				switch (user_inp2) {
					case 1:
						usleep(300000);
						goto search_another3;
						break;
					case 2:
						usleep(300000);
						goto mainmenu;
						break;
					default:
						usleep(300000);
						goto mainmenu;
						break;
				}
				
				
				break;
				
				
				
				
///////////////////////////////////////////////////increase borrow time////////////////////////////////////////////////////////////////
			case 4: 
			
				wrongbname:
				
				system("cls");	
					
				cout << endl << "ENTER THE BOOK'S TITLE: ";
				getline(cin,bookname);
				getline(cin,bookname);
				
				for (int i=0; i<books_num2; i++) {
					
					if (Book[i].name==bookname) {
						if (Book[i].rentedby==User[iterator].id) {
						book_i=i;
						break;
						}
						else { 
								usleep(300000);
								system("cls");
								cout << endl << "YOU DIDN'T BORROW THIS BOOK" << endl;
								cout << endl << " 1. INCREASE FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
								cout << "??: ";
								cin >> temp_;
								switch (temp_) {
									case 1:
										goto wrongbname;
										break;
									case 2:	
										goto mainmenu;
										break;
									default:
										goto mainmenu;
									break; 
									}
							}
					}
					if (i==books_num2-1) {
						usleep(300000);
						system("cls");
						cout << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY!" << endl;
						cout << endl << " 1. INCREASE FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
						cout << "??: ";
						cin >> temp_;
						switch (temp_) {
							case 1:
								usleep(300000);
								goto wrongbname;
								break;
							case 2:	
								usleep(300000);
								goto mainmenu;
								break;
							default:
								usleep(300000);
								goto mainmenu;
								break; 
						}
						
					
					}
					
				}
				
				
				if (Book[book_i].inline_num=="0") {
					
					temp_= stoi(Book[book_i].deliverdate);
					month_= temp_%100;
					temp_=temp_/100;
					day_= temp_%100;
					temp_=temp_/100;
					year_=temp_;
					
					day_+=7;
					
					if (day_>31) { day_=day_-31;
						month_++;
					} 
					if (month_>11) { month_= month_-11;
						year_++;
					}
					
					if (day_<10) { day= "0" + to_string(day_); }
					else { day= to_string(day_); }
					
					if (month_<10) { month= "0" + to_string(month_); } 
					else { month= to_string(month_); }
					
					year= to_string(year_);
					
					Book[book_i].deliverdate= year+day+month;
					
					booksavetofile();
					
					usleep(800000);
					system("cls");
					
					cout << endl << " YOUR BORROW TIME HAS BEEN INCREASED SUCCESSFULLY!" << endl;
					cout << " Your new delivery date is: " << year << " " << day << " " << month << endl;
					cout << endl << " 1. INCREASE FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
					cout << "??: ";
					cin >> temp_;
					switch (temp_) {
						case 1:
							usleep(300000);
							goto wrongbname;
							break;
						case 2:	
							usleep(300000);
							goto mainmenu;
							break; 
						default:
							usleep(300000);
							goto mainmenu;
							break; 
					}
					
				} else {
					
					usleep(800000);
					system("cls");
					
					cout << endl << " THE BOOK IS RESERVED FOR OTHER MEMBERS." << endl;
					cout << " SO WE ARE UNABLE TO INCREASE THE TIME." << endl;
					cout << endl << " 1. CHECK FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU.";
					cin >> temp_;
					switch (temp_) {
						case 1:
							usleep(300000);
							goto wrongbname;
							break;
						case 2:
							usleep(300000);
							goto mainmenu;
						default:
							usleep(300000);
							goto mainmenu;
					}
					
				}
				
				break;
				
				
				
//////////////////////////////////////////////////////pay the delivery delay penalty////////////////////////////////////////////////////
			case 5:
				
				wrongbname2:
					
				system("cls");
					
				cout << endl << " ENTER THE BOOK'S TITLE': " << endl;
				cout << " ??: ";
				getline(cin,bookname);
				getline(cin,bookname);
				
				for (int i=0; i<books_num2; i++) {
					
					if (Book[i].name==bookname) {
						if (Book[i].rentedby==User[iterator].id) {
						book_i=i;
						break;
						}
						else { 
								system("cls");
								cout << endl << " YOU DIDN'T BORROW THIS BOOK." << endl;
								cout << endl << " 1. PAY FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
								cout << " ??: ";
								cin >> temp_;
								switch (temp_) {
									case 1:
										usleep(300000);
										goto wrongbname2;
										break;
									case 2:	
										usleep(300000);
										goto mainmenu;
										break;
									default:
										usleep(300000);
										goto mainmenu;
										break; 
									}
							}
					}
					if (i==books_num2-1) {
						
						system("cls");
				
						cout << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY!" << endl;
						cout << endl << " 1. CHECK FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
						cout << " ??: ";
						cin >> temp_;
						switch (temp_) {
							case 1:
								usleep(300000);
								goto wrongbname2;
								break;
							case 2:	
								usleep(300000);
								goto mainmenu;
								break;
							default:
								usleep(300000);
								goto mainmenu;
								break; 
						}
					}	
				}
				
				
				temp_= stoi(Book[book_i].deliverdate);

				month_= temp_%100;
				temp_= temp_/100;
				day_= temp_%100;
				temp_= temp_/100;
				year_= temp_;
				temp_= (year_-(localdate("Year")+1900))*365 + (month_-localdate("Month")-1)*30 + (day_-localdate("Day"));
				
				cout << endl << " Your delivery date is: " << year_ << " " << day_ << " " << month_ << endl;
				
				if (temp_>=0) { cout << " You have " << temp_ << " days remaining." << endl; }
				else {
						temp_= temp_*(-1);
						cout << " You are " << temp_ << " days late!" <<endl;
					    latencyprice= stoi(Book[book_i].delaycost);
					    cout << " Your latency penalty is: " << temp_*latencyprice << " Tomans;"; 
				}
				
				
				cout << endl << endl << endl;
				cout << " WHAT TO DO NEXT?" << endl << " 1. PAY FOR ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU" << endl;
				cout << " ??: ";
				cin >> temp_;
				switch (temp_) {
					case 1:
						usleep(300000);
						goto wrongbname2;
						break;
					case 2:	
						usleep(300000);
						goto mainmenu;
						break;
					default:
						usleep(300000);
						goto mainmenu;
						break; 
				}
				
				
				

				
				break;
				
				
			
//////////////////////////////////////////////////////see borrowed books info////////////////////////////////////////////////////////////
			case 6:
				
				int bnum = stoi(User[iterator].borrownum);
				
				if (bnum==0) { cout << endl << " YOU DIDN'T BORROW ANY BOOK.";}
				else {
					cout << "-----------------------------------------------------------";
					for (int i=0; books_num2; i++) {
				
						if (User[iterator].id==Book[i].rentedby) {
					
							cout << endl << endl << " ID: " << Book[i].id << endl; 
							cout << " TITLE: " << Book[i].name << endl;
							cout << " AUTHOR: " << Book[i].author << endl;
							cout << " DELAYCOST: " << Book[i].delaycost << endl;
							cout << " DELIVER DATE: " << Book[i].deliverdate << endl;
							
							usleep(400000);					
						}	
					
					}	
										
				}	
				
				cout << endl << endl << " PRESS ANY KEY TO GO TO MAIN MENU...";
				cin >> user_inp2;
				
				system("cls");
				cout << "GOING TO MAIN MENU.";
				usleep(500000);
				system("cls");
				cout << "GOING TO MAIN MENU..";
				usleep(500000);
				system("cls");
				cout << "GOING TO MAIN MENU...";
				usleep(500000);
				goto mainmenu;
				
				
				break;	
		
		
		
		
		}
			
		
		
	}
	
	
	
///////////////////////////////////////////////////////////////admin interface/////////////////////////////////////////////////////////////////

	if (position=="admin") {
		
		
		cout << endl << " WHAT WOULD YOU LIKE TO DO?" << endl;
		cout << " 1. EDIT BOOKS' INFORMATION." << "			" << "2. ADD A NEW BOOK." << endl;
		cout << " 3. DELETE A BOOK." << endl;
		cout << " ??: "; 
		
		do {
				cin >> inp;
				if (inp!=1 && inp!=2 && inp!=3) { cout << endl << " WRONG INPUT!!" << endl;
				cout << " ENTER ANOTHER: ";
				}
		}
		while (inp!=1 && inp!=2 && inp!=3 );
		
		
		int temp3;
		int inp3;
		string bookname;
		string book_id; //case 2
		int book_i2; //case 3
		bool available; // case 3
		int admin_inp; // case 3
		bool check_; // case 1
		
		
		switch (inp) {
			
			
		/////////////////////////////////////////////////////////edit books//////////////////////////////////////////////////
			case 1:
				
				edit_another:
					
				system("cls");
					
				cout << endl << " ENTER THE BOOK'S TITLE: ";
				
				do {
					
						getline(cin,bookname);
						getline(cin, bookname);
				
						for (int i=0; i<books_num2; i++) {
					
							
							if (bookname==Book[i].name) {
							
								temp3=i;
								check_=true;
								break;
															
							}
							
							else if (i==books_num2-1) {
								system("cls");
								cout << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY!";
								cout << endl << " ENTER ANOTHER: ";
								check_=false;
								break;
							}
							
					
						}
					
				} while (check_==false);
					
				
			
			
				cout << endl << " WHAT WOULD YOU LIKE TO CHANGE?";
				cout << endl << " 1. BOOK'S TITLE'." << "		" << "2. AUTHOR'S NAME";
				cout << endl << " 3. DELAY COST. " << endl;
				cout << "??: ";
			
			
				do {
						cin >> inp3;
						if (inp3!=1 && inp3!=2 && inp3!=3) { 
							system("cls");
							cout << endl << " WRONG INPUT!!" << endl;
							cout << " ENTER ANOTHER: ";
							}
				}
				while (inp3!=1 && inp3!=2 && inp3!=3 );
				
				if (inp3==1) { cout << endl << " ENTER THE NEW NAME: ";
							   getline(cin,Book[temp3].name);
							   getline(cin,Book[temp3].name);
							   cout << endl << " IT HAS BEEN EDITED SUCCESSFULLY!";
				}
			
				if (inp3==2) { cout << endl << " ENTER THE NEW AUTHOR'S NAME: ";
							   getline(cin,Book[temp3].author);
							   getline(cin,Book[temp3].author);
							   cout << endl << " IT HAS BEEN EDITED SUCCESSFULLY!";
				}
			
				if (inp3==3) { cout << endl << " ENTER THE NEW DELAY COST: ";
							   getline(cin,Book[temp3].delaycost);
							   getline(cin,Book[temp3].delaycost);
							   cout << endl << " IT HAS BEEN EDITED SUCCESSFULLY!!";
				}
				
				booksavetofile();
				
				usleep(3000000);
				
				system("cls");
				
				cout << endl << " WHAT TO DO NEXT?" << endl;
				cout << endl << " 1. EDIT ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
				cout << "??: ";
				
				cin >> admin_inp;
				switch (admin_inp) {
					case 1:
						usleep(300000);
						goto edit_another;
						break;
					case 2:
						usleep(300000);
						goto mainmenu;
						break;
					default:
						usleep(300000);
						goto mainmenu;
						break;
					}
				
				break;
			
			
			
			////////////////////////////////////////////////////// add a new book//////////////////////////////////////////////////////////////////////////
			case 2: 
				
				add_another:
				
				system("cls");
				
		
				
				do {
					
					book_id=random_id();
					check_= id_check(book_id);
					
				}
				while (check_==false);
				
				
				Book[books_num2].id = book_id;
				
				cout << endl << " ENTER THE BOOK'S NAME: ";
				getline(cin,temp);
				getline(cin,temp);
				Book[books_num2].name = temp;
				
				cout << endl << " ENTER THE BOOK'S AUTHOR: ";
				getline(cin,temp);
				Book[books_num2].author = temp;
				
				cout << endl << " ENTER THE BOOK'S DELAY COST: ";
				getline(cin,temp);
				Book[books_num2].delaycost = temp;
				
				Book[books_num2].rentedby = '0';
				Book[books_num2].deliverdate = "no date";
				Book[books_num2].inline_num = '0';
				booknumchange("increase");
				booksavetofile();
				
				usleep(500000);
				system("cls");
				cout << endl << " " << Book[books_num2-1].name << " has been added to your library." << endl;
				
				usleep(4000000);
				system("cls");
				
				cout << endl << " WHAT TO DO NEXT?" << endl;
				cout << endl << " 1. ADD ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
				cout << "??: ";
				
				cin >> admin_inp;
				switch (admin_inp) {
					case 1:
						usleep(300000);
						goto add_another;
						break;
					case 2:
						usleep(300000);
						goto mainmenu;
						break;
					default:
						usleep(300000);
						goto mainmenu;
						break;
					}
						
				break;
		
		
			
            /////////////////////////////////////////////delete a book/////////////////////////////////////////////////////////////////////////
			case 3:
				
				book_sort(books_num2);
				
				search_another4:
				
				system("cls");
				
				cout << endl << " THE AVAILABLE BOOKS FOR DELETION BY ORDER ARE: " << endl << endl;
				
				for (int i=0; i<books_num2; i++) {
					
					if (Book[i].rentedby=="0") {
						usleep(200000);
						cout << " ID: " << Book[i].id << endl;
						cout << " TITLE: " << Book[i].name << endl;
						cout << " AUTHOR: " << Book[i].author << endl;
						cout << " DELAY COST: " << Book[i].delaycost << endl;
						cout << "-----------------------------------------" << endl << endl;
						
					}	
				}
				
							
				cout << endl << " ENTER THE BOOK'S TITLE: ";
				getline(cin,bookname);
				getline(cin,bookname);
				
				for (int i=0; i<books_num2; i++) {
					
					if (bookname==Book[i].name ) {
						if (Book[i].rentedby=="0") {
							book_i2=i;
							available=true;
							break;
						}
						else { 
							usleep(200000);
							system("cls");
							cout << endl << " THIS BOOK IS NOT AVAILABLE FOR DELETION.";
							available= false;
							break;
						}
					}
					
					if (i==books_num2-1) {
						usleep(200000);
						system("cls");
						cout << endl << " THIS BOOK IS NOT AVAILABLE IN OUR LIBRARY";
						available= false;
						break;
					}
					
				}
				
				
				if (available==false) {
					
					cout << endl << endl << " 1. SEARCH ANOTHER BOOK." << "		" << " 2. GO TO MAIN MENU." << endl;
					cout << "??: ";
					cin >> admin_inp;
					switch(admin_inp) {
						case 1:
							goto search_another4;
							break;
						case 2: 
							goto mainmenu;
							break;
						default:
							goto mainmenu;
							break;
					}	
				}
				
				
				
				
				ofstream delete_("Books.txt");
				for (int i=0; i<books_num2; i++) {
					
					if (i==book_i2) {continue;}
					else {
						
						delete_ << Book[i].id << endl;
						delete_ << Book[i].name << endl;
						delete_ << Book[i].author << endl;
						delete_ << Book[i].delaycost << endl;
						delete_ << Book[i].rentedby << endl;
						delete_ << Book[i].deliverdate << endl;
						delete_ << Book[i].inline_num << endl;
						
						inline_num2= stoi(Book[i].inline_num);
						
						for (int j=0; j<inline_num2; j++) {
							
							delete_ << Book[i].inline_num[j] << endl;
							
						}
						
						
						if (book_i2==books_num2-1) {
							
							if (i!=books_num2-2) { delete_ << "//////////////////////////////////////////////////////////////" << endl;}
							else if(i==books_num2-2) { delete_ << "//////////////////////////////////////////////////////////";}
					
						}
						else if (book_i2!=books_num2-1) {
							if (i==books_num2-1) { delete_ << "/////////////////////////////////////////////////////////////////";}
							else if (i!=books_num2-1) { delete_ << "////////////////////////////////////////////////////////////////" << endl;
							}
						}
						
					}
				}
				delete_.close();
				
				booknumchange("decrease");
				
				book_import_func();
				
				usleep(300000);
				system("cls");
				
				cout << endl << " " << bookname << " NO LONGER EXISTS IN YOUR LIBRARY.";
				
				usleep(2500000);
				system("cls");
				
				cout << endl << " WHAT TO DO NEXT?" << endl;
				cout << " 1. DELETE ANOTHER BOOK." << endl;
				cout << " 2. GO TO MAIN MENU." << endl;
				cout << "??: ";
				cin >> admin_inp;
				
				switch(admin_inp) {
					case 1:
						goto search_another4;
						break;
					case 2: 
						goto mainmenu;
						break;
					default:
						goto mainmenu;
						break;
				}	
				
				
				break;
						
		}
			
	}
	
	////////////////////////////////////////////////////////////////////////THE END////////////////////////////////////////////////////////////////////////
	
	return 0;
}






























